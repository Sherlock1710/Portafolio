/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inventario;

import gui.Principal;

/**
 *
 * @author USER
 */
public class Inventario {

    public static void main(String[] args) {
        
        Principal p = new Principal();
        
        p.setVisible(true);
        p.setLocationRelativeTo(null);
        
    }
}
